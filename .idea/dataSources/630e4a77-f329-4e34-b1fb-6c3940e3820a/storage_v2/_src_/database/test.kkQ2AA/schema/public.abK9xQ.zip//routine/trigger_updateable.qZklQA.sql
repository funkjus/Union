create function trigger_updateable() returns trigger
    language plpgsql
as
$$
BEGIN
	new.updated := CURRENT_TIMESTAMP;
	RETURN new;
END
$$;

alter function trigger_updateable() owner to postgres;

