create function trigger_updatable() returns trigger
    language plpgsql
as
$$
BEGIN
	new.updated := CURRENT_TIMESTAMP;
	RETURN new;
END
$$;

alter function trigger_updatable() owner to postgres;

